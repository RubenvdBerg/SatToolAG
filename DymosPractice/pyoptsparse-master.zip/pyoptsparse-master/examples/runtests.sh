python hs015.py --opt=snopt --storeHistory=1
python hs015.py --opt=slsqp --storeHistory=1
python hs015.py --opt=nlpqlp --storeHistory=1
python hs015.py --opt=fsqp --storeHistory=1
python hs015.py --opt=ipopt --storeHistory=1
python hs015.py --opt=conmin --storeHistory=1
python hs015.py --opt=psqp --storeHistory=1
