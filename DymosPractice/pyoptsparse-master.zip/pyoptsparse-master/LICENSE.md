# pyOptSparse

pyOptSparse is a Python wrapper for using multiple optimization packages using the same API.
______________________________________________________________________________

Copyright (c) 2011 University of Toronto\
Copyright (c) 2014 University of Michigan\
Additional copyright (c) 2014 Gaetan K. W. Kenway, Ruben Perez, Charles A. Mader, and\
Joaquim R. R. A. Martins\
All rights reserved.
______________________________________________________________________________

pyOptSparse is licensed under the GNU Lesser General Public License (the "License"); you may not use this software except in compliance with the License. You may obtain a copy of the License at:\
https://www.gnu.org/licenses/lgpl.html
______________________________________________________________________________

University of Michigan's Multidisciplinary Design Optimization Laboratory (MDO Lab)\
College of Engineering, Aerospace Engineering Department\
http://mdolab.engin.umich.edu/
______________________________________________________________________________
