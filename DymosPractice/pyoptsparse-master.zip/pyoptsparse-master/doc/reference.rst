.. _reference:

pyOptSparse API Documentation
=============================

.. toctree::
   :maxdepth: 2

   api/optimization
   api/optimizer
   api/constraint
   api/variable
   api/gradient
   api/history
