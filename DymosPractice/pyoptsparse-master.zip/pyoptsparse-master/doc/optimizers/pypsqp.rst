.. _psqp:

PSQP
----
This optimizer implements a sequential quadratic programming method
with a BFGS variable metric update

.. currentmodule:: pyoptsparse.pyoptsparse.pyPSQP.pyPSQP

.. autoclass:: PSQP
   :members: __call__

