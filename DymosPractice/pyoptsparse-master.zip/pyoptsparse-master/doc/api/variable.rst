.. _variable:

Variable
--------

.. currentmodule:: pyoptsparse.pyoptsparse.pyOpt_variable

.. autoclass:: Variable
   :members:
