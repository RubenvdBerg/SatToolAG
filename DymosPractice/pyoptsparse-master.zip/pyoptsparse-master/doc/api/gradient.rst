.. _gradient:

Gradient
--------

.. currentmodule:: pyoptsparse.pyoptsparse.pyOpt_gradient

.. autoclass:: Gradient
   :members:
