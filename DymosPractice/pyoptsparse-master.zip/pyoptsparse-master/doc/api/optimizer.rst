.. _optimizer:

Optimzer
--------

.. currentmodule:: pyoptsparse.pyoptsparse.pyOpt_optimizer

.. autoclass:: Optimizer
   :members:

.. automodule:: pyoptsparse.pyoptsparse.pyOpt_optimizer
   :members: OPT
