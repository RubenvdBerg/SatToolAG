.. _history:

History
-------

.. currentmodule:: pyoptsparse.pyoptsparse.pyOpt_history

.. autoclass:: History
   :members:
