.. _optimization:

Optimziation
------------

.. currentmodule:: pyoptsparse.pyoptsparse.pyOpt_optimization

.. autoclass:: Optimization
   :members: __init__, addVar, addVarGroup, delVar, delVarSet, addCon, addConGroup, printSparsity, getDVs, setDVs, setDVsFromHistory
