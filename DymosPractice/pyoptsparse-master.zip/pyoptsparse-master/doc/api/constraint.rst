.. _constraint:

Constraint
----------

.. currentmodule:: pyoptsparse.pyoptsparse.pyOpt_constraint

.. autoclass:: Constraint
   :members:
