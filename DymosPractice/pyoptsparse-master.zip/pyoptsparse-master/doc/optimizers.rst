.. _optimizers:

Optimizers
==========

.. toctree::
   :maxdepth: 2

   optimizers/pysnopt
   optimizers/pyipopt
   optimizers/pyslsqp
   optimizers/pynlpql
   optimizers/pyfsqp
   optimizers/pynsga2
   optimizers/pypsqp

