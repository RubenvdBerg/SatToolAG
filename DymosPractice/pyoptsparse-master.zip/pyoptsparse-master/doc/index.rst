.. pyOptSparse documentation master file, created by
   sphinx-quickstart on Sat Dec  7 13:50:49 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. _pyoptsparse:

===========
pyOptSparse
===========

PYthon OPTimization (Sparse) Framework

`pyOptSparseSparse` is a replacement for pyOpt.

.. toctree::
   :maxdepth: 2

   introduction
   changes
   install
   tutorial
   guide
   optimizers
   reference
   postprocessing
